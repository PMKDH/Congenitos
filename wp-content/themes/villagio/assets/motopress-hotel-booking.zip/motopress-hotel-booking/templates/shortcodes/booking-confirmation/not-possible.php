<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php _e( 'Confirmation of your booking request is not possible for some reason. Please start a new booking request.', 'motopress-hotel-booking' ); ?>
</p>