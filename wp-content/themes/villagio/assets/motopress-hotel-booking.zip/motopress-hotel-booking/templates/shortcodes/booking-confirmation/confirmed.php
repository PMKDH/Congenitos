<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php _e( 'Your booking is confirmed. Thank You!', 'motopress-hotel-booking' ); ?>
</p>