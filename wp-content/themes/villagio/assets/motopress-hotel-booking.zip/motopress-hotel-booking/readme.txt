=== Hotel Booking ===
Contributors: MotoPress
Donate link: https://motopress.com/
Tags: hotel, booking, reservation, rental, property
Requires at least: 4.0
Tested up to: 4.9
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Manage your hotel booking services.

== Description ==

Manage your hotel booking services. Perfect for hotels, villas, guest houses, hostels, and apartments of all sizes.

== Installation ==

1. Upload the MotoPress plugin to the /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Screenshots ==


== Copyright ==

Hotel Booking plugin, Copyright (C) 2018, MotoPress https://motopress.com/
Hotel Booking plugin is distributed under the terms of the GNU GPL.


== Credits ==

* Beanstream, https://github.com/bambora-na/beanstream-php/, Copyright (c) 2014 Pavel Kulbakin, MIT License.
* Spectrum Colorpicker, https://github.com/bgrins/spectrum, Author: Brian Grinstead, MIT License.
* Braintree, https://github.com/braintree/braintree_php, Copyright 2015 Braintree, a division of PayPal, Inc., MIT License.
* CanJS, http://canjs.com/, Copyright 2016 Bitovi, MIT License.
* SerializeJSON jQuery plugin, https://github.com/marioizquierdo/jquery.serializeJSON, Copyright (c) 2012, 2015 Mario Izquierdo, Dual licensed under the MIT and GPL licenses.
* Datepick, http://keith-wood.name/datepick.html by Keith Wood Licensed under the MIT licence.
* Magnific Popup, http://dimsemenov.com/plugins/magnific-popup/, Copyright 2016 Dmitry Semenov, MIT License.
* jQuery FlexSlider, https://github.com/woocommerce/FlexSlider, Copyright 2012 WooThemes,  Contributing Author: Tyler Smith, GNU General Public License v2.0.


== Changelog ==

= 2.7.0, May 18 2018 =
* Added the ability to create a reservation manually.
* Added terms and conditions checkbox to booking confirmation page.

= 2.6.1, Apr 23 2018 =
* Fix: Reverted CSS class of image galleries as it breaks some themes.

= 2.6.0, Apr 20 2018 =
* Added the ability to set different prices for one accommodation based on a number of guests.
* Optimized the image galleries of accommodations.
* Added support for Jetpack Lazy Images Module.
* Fixed the bug with displaying the age of children in the search availability form added via a shortcode.
* Fixed the price format in the Recommended accommodations section.

= 2.5.0, Apr 4 2018 =
* Minor bugfixes and improvements.

= 2.4.4, Mar 14 2018 =
* Improved compatibility with Elementor Page Builder plugin.
* Fixed the bug with missing slash in calendar URL.

= 2.4.3, Mar 7 2018 =
* Added a new option to skip search results page and enable direct booking from accommodation pages.

= 2.4.2, Feb 28 2018 =
* Fixed the bug with check-in and check-out time not saving. Time settings were set to 24-hour clock system.
* Added tags to Accommodations.
* Added the following mphb_rooms shortcode parameters: category, tags, IDs and relation. Now you can display accommodations by categories, tags or accommodation IDs.
* Added a new field to settings where you can set a standard child's age accepted in your hotel establishment. This is an optional text, which will complete "Children" field label clarifying this info for your visitors.
* Improved the search availability calendar. Now it correctly displays the minimum stay-in days depending on a check-in date.
* Fixed the bug with all dates displaying as unavailable within certain booking rules.
* Fixed the bug with a custom rule not being applied because of a global booking rule.
* Fixed the bug with the Availability calendar not showing the correct number of available accommodations.
* Added "Blocked accommodation" status to the Booking Calendar.
* Added a new DESCRIPTION field with the booking info to the Export Calendar in iCal format.
* The Export Calendar in iCal format now shows the SUMMARY in the following format: first name, last name and booking_id.
* Now the booking information from external calendars is sent across booking channels without changes.
* Fixed the error with deleting an expiration date of the coupon code.

= 2.4.1, Jan 31 2018 =
* Added support of WooCommerce Payments extension.
* Bug fix: fixed fatal error on booking confirmation page.

= 2.4.0, Jan 24 2018 =
* Added the ability to add accommodation taxes, services taxes, fees (mandatory services) and taxes on fees.

= 2.3.1, Dec 22 2017 =
* Added the ability to enable automatic external calendars synchronization.
* Fixed the bug with the rate duplication.
* Fixed localization issues of accommodation titles featured in "Recommended" block.
* Fixed the bug with the NextGen gallery plugin.

= 2.3.0, Dec 13 2017 =
* Added more flexible booking rules:
  * ability to set check-in check-out dates for individual accommodation types during chosen seasons;
  * ability to set minimum and maximum stay-in days for individual accommodation types during chosen seasons;
  * ability to block individual accommodation types and actual accommodations for chosen dates;
* Note: This release will perform an upgrade process on the database in the background. Please make sure that your previous booking rules are successfully transformed into new ones.
* Updated translation files. 
* Please note! Due to peculiarities of multilingual settings, the titles of custom post types and taxonomy (e.g. accommodation types, categories) are not translated from English into other languages in the URLs of the pages.

= 2.2.0, Oct 9 2017 =
* Implemented bookings synchronization with online channels via iCal interface.
* Replaced Services text 'per night' with 'per day'.
* Renamed Facilities to Amenities.
* Bug fixed: Stripe is now displayed on the Booking confirmation page even if it's the only payment method selected.
* Bug fixed: the amount of Accommodation types displayed in widget is now not dependent on the global WordPress settings.
* Removed limit for setting the number of adults and children in Accommodation type menu.
* Fixed the link for viewing a booking in the administrator's email.
* Fixed the rate duplication issue when clicking on a link in the list of rates.
* Fixed the issue with the %customer_note% tag that was not displayed in email.

= 2.1.2, Aug 14 2017 =
* Bug fix: put "beds" back to Settings.
* The Booking Confirmation page update: guests must select the number of adults and children.

= 2.1.1, Jul 19 2017 =
* Bug fix: fixed the placeholder of posts titles.

= 2.1.0, Jul 13 2017 =
* Added the ability to create and apply coupon codes.

= 2.0.0, Jun 28 2017 =
* Note: This release will perform an upgrade process on the database in the background.
* Note: This release adds new tags for email templates. Update your templates please. To reset an email template just remove the current text and save settings.
* Note: This release doesn't limit the number of adults and children in the Search availability form. Please update "Max Adults" and "Max Children" number in plugin settings.
* The updated plugin allows guests reserve and pay for several (more than one) accommodation types during one reservation process.
* Search results page was updated: guests can choose and add several accommodation types into one reservation.
* On the search results page, the plugin displays all recommended accommodations according to the number of guests specified in a search request. This option can be turned off.
* Email templates were updated to support Multiple booking.
* Admin page descriptions were updated to ease the work with the plugin.
* Bug fix: fixed the issue with saving check-in and check-out dates in Settings.
* Improved compatibility with Jetpack gallery and lightbox modules.
* Added a theme-friendly pagination option that allows specify the number of posts per page for accommodations and services.
* A cancellation email template is available as a separate tag - it's used when a booking cancellation option is turned on.
* A Price Breakdown Table on the Booking confirmation page was updated: it's now smaller with the ability to expend details of each booked accommodation.
* Updated the list of data your guests are required to provide when submitting a booking. Admins can set it to: no data required / country required / full address required. Please choose the preferable option.
* 15 new themes were added to calendar to fit your theme design much better.
* New filters, actions and CSS classes were added for developers.

= 1.2.3, May 12 2017 =
* Added the ability to receive payments through Beanstream/Bambora payment gateway.

= 1.2.2, Apr 26 2017 =
* Added the ability to receive payments through Braintree payment gateway.

= 1.2.1 Apr 24 2017 =
* Bug fix: fixed the issue of undelivered emails after booking placement.
* Bug fix: fixed the issue of booking calendar localization.

= 1.2.0, Mar 29 2017 =
* New algorithm of displaying accommodation pricing:
  * it displays minimum available price of accommodation for dates set in the search form by visitor;
  * it displays minimum available price of accommodation from the day of visit and for the next fixed number of days predefined in settings (if dates are not chosen by visitor);
  * it displays a total price for chosen dates or the price of "minimum days to stay" set in settings.
* Added the ability to create a payment manually. Useful feature to keep all your finances in one place.
* Added the ability to search booking by email or ID in the list of bookings.
* Added the ability to filter payments by status and search them by email or ID in the list of payments.
* Added a new email template to notify Administrator about new booking, which is paid and confirmed.
* Added the ability to enable comments for accommodation and services on the frontend.
* Thumbnail size of accommodation gallery is set to 'thumbnail' to make all images the same size.
* Bug fix: fixed an issue when rates list displayed rates in the past on the frontend.
* Bug fix: fixed an issue when price of the service was displayed twice.
* Added new Arabic language files.

= 1.1.0, Mar 14 2017 =
* Added the ability to receive payments through PayPal, 2Checkout and Stripe gateways.
* Made the plugin multilingual ready.
* Added translation into 13 languages (Portuguese, Polish, Russian, Spanish, Turkish, Swedish, Italian, Hungarian, Czech, Chinese, Dutch, French, German).

= 1.0.1, Jan 13 2017 =
* Added the ability to input dates via keyboard
* Added the ability to duplicate Rate
* Added the ability to choose date format in plugin Settings

= 1.0.0, Dec 23 2016 =
* Initial release
